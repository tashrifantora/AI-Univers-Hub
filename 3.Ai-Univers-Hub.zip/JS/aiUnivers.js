const loadData = (isClicked) => {
  fetch("https://openapi.programming-hero.com/api/ai/tools")
    .then((res) => res.json())
    .then((data) => displayData(data.data.tools, isClicked));
};

// Display data
const displayData = (datas, isClicked) => {
  const cardContainer = document.getElementById("card-container");

  //Logic for[Sww more] button will show ore note
  const showAllBtn = document.getElementById("showAllBtn");
  if (datas.length > 6) {
    showAllBtn.classList.remove("hidden");
  } else {
    showAllBtn.classList.add("hidden");
  }
  if (!isClicked) {
    //Logic for Show all element
    datas = datas.slice(0, 6);
  }

  datas.forEach((data) => {
    console.log(data);
    const card = document.createElement("div");
    card.classList = `card w-96 bg-base-100 shadow-xl mb-7`;
    card.innerHTML = `
        
                    <figure class="px-10 pt-10">
                      <img src="${data.image}" alt="Shoes" class="rounded-xl" />
                    </figure>
                    <div class="card-body items-left text-left">
                    <h1 class="text-2xl font-bold">Features</h1>

                      <ol class="mb-3 list-decimal">
                         <li>${data.features[0]}
                         </li>                      
                         <li>${data.features[1]}
                         </li>                      
                         <li>${data.features[2]}
                         </li>                      
                      </ol>

                      <hr class="mb-3">
                     <div class="flex justify-between items-center ">
                      <div>
                           <p class="mb-2 text-xl font-semibold">${data.name}</p>
                          <p><span><i class="fa-regular fa-calendar-days"></i> </span>11/5/2003</p>
                      </div>
                         <i onclick='handleSingleData("${data.id}")' class="fa-solid fa-arrow-right rounded-full bg-red-50 p-3"></i>
                    </div>
                    </div>
                  
        `;
    cardContainer.appendChild(card);
  });
};

//For single details
const handleSingleData = (id) => {
  fetch(`https://openapi.programming-hero.com/api/ai/tool/ ${id}`)
  .then(res=> res.json())
  .then(data=>singleDataDetails(data));
  console.log(data)

  
};

const singleDataDetails=(info)=>{
	console.log(info)


	//Modals
	single_data_modal.showModal();
}

//Show All Button
const handleShowAll = () => {
  loadData(true);   





};

loadData();
